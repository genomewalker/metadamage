from .cli import main_cli

main_cli()