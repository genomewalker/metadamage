from metadamage.cli import main_cli

main_cli()